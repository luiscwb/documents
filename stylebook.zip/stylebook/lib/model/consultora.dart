class Consultora {
  
}