class Imagem {
  final int id;
  final String descricao;
  final DateTime inclussao;

  Imagem(this.id, this.descricao, this.inclussao);

  factory Imagem.fromJson(Map<String, dynamic> map) => new Imagem(
    map['id'],
    map['descricao'],
    map['inclussao'],
  );
}
