
class Dossie {
  final int id;
  final int idCliente;
  final String objetivo;
  final String rotina;

  Dossie(
    this.id,
    this.idCliente,
    this.objetivo,
    this.rotina,
  );

  Map<String, dynamic> toJson() {
    Map<String, dynamic> objMap = {
      'id': this.id,
      'idCliente': this.idCliente,
      'objetivo': this.objetivo,
      'rotina': this.rotina,
    };
    return objMap;
  }

  factory Dossie.fromJson(Map<String, dynamic> map) => 
    new Dossie(
      map['id'],
      map['idCliente'],
      map['objetivo'],
      map['rotina'],
    );
}
