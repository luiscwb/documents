class Caracteristica {
  final int id;
  final String descricao;

  Caracteristica(
    this.id,
    this.descricao,
  );

  factory Caracteristica.fromJson(Map<String, dynamic> map) =>
    new Caracteristica(
      map['id'],
      map['descricao'],
  );

  //Objeto para Json
  Map<String, dynamic> toJson() {
    Map<String, dynamic> objMap = {
      'id': this.id,
      'conta': this.descricao,
    };
    return objMap;
  }
}
