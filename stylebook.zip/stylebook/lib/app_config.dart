import 'dart:convert';

import 'package:flutter/services.dart';

class AppConfig {

  final String urlConsultoraSave;
  final String urlConsultora;
  final int httpTimeout;

  AppConfig({
    this.urlConsultoraSave,
    this.urlConsultora,
    this.httpTimeout = 5,
  });


  static Future<AppConfig> load () async {
    return forEnvironment('des');
  }

  static Future<AppConfig> forEnvironment(String env) async {
    // set default to dev if nothing was passed
    env = env ?? 'dev';

    // load the json file
    final contents = await rootBundle.loadString(
      'assets/config/$env.json',
    );

    // decode our json
    final json = jsonDecode(contents);

    // convert our JSON into an instance of our AppConfig class
    return AppConfig(
      urlConsultora: json['urlConsultora'],
      urlConsultoraSave: json['urlConsultoraSave'],
      httpTimeout: json['urlTimeout']
    );
  }
}


// void main({String env}) async {
//   // load our config
//   final config = await AppConfig.forEnvironment(env);

//   // pass our config to our app
//   runApp(MyApp(config));
// }
