class RetornoHttpService {
  final String codigoRetorno;
  final String mensagemRetorno;
  final String execaoRetorno;
  final dynamic dadosRetorno;

  RetornoHttpService(
    this.codigoRetorno,
    this.mensagemRetorno,
    this.execaoRetorno,
    this.dadosRetorno,
  );

 factory RetornoHttpService.fromJson(Map<String, dynamic> map) => new RetornoHttpService(
    map['codigoRetorno'],
    map['mensagemRetorno'],
    map['execaoRetorno'],
    map['dadosRetorno'],
  );

}
