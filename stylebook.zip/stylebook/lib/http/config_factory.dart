import 'package:stylebook/app_config.dart';


class ConfigFactory {

  static AppConfig getAppConfig() {
    //AppConfig conf = AppConfig.load();
    //return conf;
    return null;
  }
  
 
  
}