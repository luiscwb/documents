import 'package:http/http.dart';
import 'package:stylebook/http/interceptor.dart';
import 'package:http_interceptor/http_client_with_interceptor.dart';
import 'package:stylebook/model/dossie.dart';
import 'package:stylebook/model/imagem.dart';


Client client = HttpClientWithInterceptor.build(interceptors: [LoggingInterceptor()]);


void salvarDossie(Dossie dos) async {
   final Response response = await client.get('url_webapi').timeout(Duration(seconds: 5));
}

void salvarImagemDeDossie(Dossie dos, Imagem img)  async {
   final Response response = await client.get('url_webapi').timeout(Duration(seconds: 5));
}

void exlcuirImagemDeDossie(Dossie dos, Imagem img)  async {
  //repoDossie.delImageForDossie( dos.getId(), img.getId() );
  //repoImagem.deleteById( img.getId() );
   final Response response = await client.get('url_webapi').timeout(Duration(seconds: 5));
}

Future<List<Imagem>> recuperarImagensPorDeDossieId( int id)  async {
     final Response response = await client.get('url_webapi').timeout(Duration(seconds: 5));
}

