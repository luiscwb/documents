
import 'package:http/http.dart';
import 'package:stylebook/http/interceptor.dart';
import 'package:stylebook/model/consultora.dart';
import 'package:http_interceptor/http_client_with_interceptor.dart';

Future<List<Consultora>> salvarConsultora() async {

Client client = HttpClientWithInterceptor.build(interceptors: [LoggingInterceptor()]);

final Response response = await client.get('url_webapi').timeout(Duration(seconds: 5));

}
