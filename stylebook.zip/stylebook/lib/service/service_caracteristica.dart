import 'dart:convert';

import 'package:http/http.dart';
import 'package:stylebook/http/interceptor.dart';
import 'package:http_interceptor/http_client_with_interceptor.dart';
import 'package:stylebook/http/retorno_httpservice.dart';
import 'package:stylebook/model/caracteristica.dart';
import 'package:stylebook/model/imagem.dart';

Client client =
    HttpClientWithInterceptor.build(interceptors: [LoggingInterceptor()]);

Future<List<Caracteristica>> recuperarCaracteristcas() async {
  
  final String endPoint = "http://ip_notebook/stylebook/caracteristica/findall";

  // Chama Endpoint
  final Response response =
      await client.get(endPoint).timeout(Duration(seconds: 5));

  // Obtem Json da resposta
  final dynamic decodedJson = jsonDecode(response.body);

  // Cosntroi objeto RetornoHttpService com o Json da resposta
  final RetornoHttpService retornoService =
      RetornoHttpService.fromJson(decodedJson);

  // retornoService.dadosRetorno contem Json de lista de Caracteristicas
  // Ncessario realizar iteração para extrair cada caracteristica
  List<Caracteristica> listCar = List();
  for (Map<String, dynamic> car in retornoService.dadosRetorno) {
    listCar.add(Caracteristica.fromJson(car));
  }

  return listCar;
}




Future<void> salvarCaracteristica( Caracteristica car) async {

  final String endPoint = "http://ip_notebook/stylebook/caracteristica/save";

  // Controi body com Json de dados de entrada
  final String caractJson = jsonEncode( car.toJson() );

  // Chama Endpoint
  final Response response = await client
    .post(
      endPoint,
      headers: {'Content-type' : 'application/json'},
      body: caractJson,
    )
    .timeout(Duration(seconds: 5));

  // Obgem Json da resposta
  final dynamic decodedJson = jsonDecode(response.body);

}



Future<void> salvarImagemDeCaracteristica(Caracteristica car, Imagem img) async {

  final String endPoint = "http://ip_notebook/stylebook/caracteristica/saveXXX";

  // Controi body com Json de dados de entrada
  final String caractJson = jsonEncode( car.toJson() );

  // Chama Endpoint
  final Response response = await client
    .post(
      endPoint,
      headers: {'Content-type' : 'application/json'},
      body: caractJson,
    )
    .timeout(Duration(seconds: 5));

  // Obgem Json da resposta
  final dynamic decodedJson = jsonDecode(response.body);

}
